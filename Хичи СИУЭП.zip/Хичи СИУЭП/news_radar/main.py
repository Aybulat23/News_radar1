"""Новостной радар Сургута и Югры — точка входа."""
import argparse, logging, sys, time
from config_loader import load_config
from collector import fetch_all
from database import init_db, is_new, save_news, get_history, get_stats
from ranker import calculate_score
from notifier import send_notification
from report import export_html

def _setup_logging(verbose: bool = False) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s  %(levelname)-7s  %(name)s  %(message)s",
        handlers=[logging.FileHandler("news_radar.log", encoding="utf-8"),
                  logging.StreamHandler(sys.stdout)],
    )
    logging.getLogger("urllib3").setLevel(logging.WARNING)

def run_once(config: dict) -> int:
    items = fetch_all(config)
    print(f"\n📡 Получено записей: {len(items)}")
    notified = fresh = 0
    for item in items:
        if not is_new(item["guid"]):
            continue
        fresh += 1
        score = calculate_score(item, config)
        should_notify = score >= config["notification_threshold"]
        if should_notify:
            sent = send_notification(item, score, config)
            should_notify = sent
            if sent: notified += 1
        save_news(item, score, notified=should_notify)
    print(f"\n✅ Новых: {fresh}. Отправлено уведомлений: {notified}.")
    return notified

def cmd_history(args) -> None:
    rows = get_history(limit=args.limit)
    if not rows:
        print("История пуста."); return
    print(f"\n{'#':>3}  {'найдено':19}  {'оценка':>6}  {'источник':25}  заголовок")
    print("─" * 110)
    for i, r in enumerate(rows, 1):
        marker = "🔥" if r["notified"] else "  "
        print(f"{i:>3}  {r['found_at']:19}  {r['score']:>6.1f}  "
              f"{(r['source'] or '')[:25]:25}  {marker} {r['title']}")

def cmd_stats() -> None:
    s = get_stats()
    print(f"\nВсего записей: {s['total']}\nОтправлено уведомл.: {s['notified']}")
    print("\nПо источникам:")
    for row in s["by_source"]: print(f"  {row['source']:<35} {row['cnt']}")

def main() -> None:
    parser = argparse.ArgumentParser(description="Новостной радар Сургута и Югры")
    parser.add_argument("--loop", type=int, default=0, help="Запускать каждые N минут")
    parser.add_argument("--history", action="store_true")
    parser.add_argument("--stats", action="store_true")
    parser.add_argument("--export", metavar="FILE", default=None)
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    _setup_logging(args.verbose)
    init_db()
    if args.history: cmd_history(args); return
    if args.stats: cmd_stats(); return
    if args.export: print(f"📄 Отчёт: {export_html(args.export)}"); return
    config = load_config()
    if args.loop <= 0: run_once(config); return
    print(f"♻️  Режим цикла: каждые {args.loop} мин. Ctrl+C для выхода.")
    try:
        while True:
            try: run_once(config)
            except Exception as exc: logging.exception("Ошибка цикла: %s", exc)
            time.sleep(args.loop * 60)
    except KeyboardInterrupt: print("\nОстановлено.")

if __name__ == "__main__":
    main()