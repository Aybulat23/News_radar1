"""Оценка важности новости."""
import time

REGION_BONUS = {"surgut": 1.5, "ugra": 1.2}

def calculate_score(item: dict, config: dict) -> float:
    score = float(item["priority"])
    score *= REGION_BONUS.get(item.get("region", ""), 1.0)
    text = f"{item.get('title', '')} {item.get('summary', '')}".lower()
    for kw in config["keywords"]["high"]:
        if kw.lower() in text: score += 5
    for kw in config["keywords"]["medium"]:
        if kw.lower() in text: score += 2
    ts = item.get("published_ts")
    if ts:
        age_h = (time.time() - ts) / 3600
        if age_h <= 1: score += 4
        elif age_h <= 6: score += 2
        elif age_h <= 24: score += 1
        elif age_h > 72: score -= 5
    return round(score, 2)