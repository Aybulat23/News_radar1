"""Генерация HTML-отчёта по истории находок."""
import html
from database import get_history, get_stats

TEMPLATE = """<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><title>Новостной радар</title>
<style>
  body {{ font-family: -apple-system, Segoe UI, sans-serif; margin: 24px; }}
  h1 {{ color: #1b3a63; }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 16px; }}
  th, td {{ border: 1px solid #ddd; padding: 8px 12px; text-align: left; }}
  th {{ background: #f5f7fa; }}
  tr:nth-child(even) {{ background: #fafbfc; }}
  .surgut {{ color: #0b6cff; font-weight: 600; }}
  .ugra {{ color: #c98100; font-weight: 600; }}
  .score {{ font-weight: 700; }}
  .notified {{ color: #15803d; }}
</style></head><body>
<h1>📡 Новостной радар — история находок</h1>
<p>Всего записей: <b>{total}</b>, отправлено уведомлений: <b>{notified}</b></p>
<p>По источникам: {by_source}</p>
<table><tr><th>#</th><th>Найдено</th><th>Источник</th><th>Регион</th><th>Оценка</th><th>Уведомление</th><th>Заголовок</th></tr>
{rows}</table></body></html>
"""

def _region_label(region: str) -> str:
    if region == "surgut": return '<span class="surgut">Сургут</span>'
    if region == "ugra": return '<span class="ugra">Югра</span>'
    return html.escape(region)

def export_html(path: str = "report.html") -> str:
    history = get_history(limit=200)
    stats = get_stats()
    rows = []
    for i, r in enumerate(history, 1):
        title = html.escape(r["title"])
        link = r["link"] or "#"
        notified = "✅" if r["notified"] else "—"
        rows.append(
            f"<tr><td>{i}</td><td>{r['found_at']}</td><td>{html.escape(r['source'] or '')}</td>"
            f"<td>{_region_label(r['region'])}</td><td class='score'>{r['score']:.1f}</td>"
            f"<td class='notified'>{notified}</td>"
            f"<td><a href='{html.escape(link)}' target='_blank'>{title}</a></td></tr>"
        )
    by_source = ", ".join(f"{s['source']}: {s['cnt']}" for s in stats["by_source"]) or "—"
    with open(path, "w", encoding="utf-8") as f:
        f.write(TEMPLATE.format(total=stats["total"], notified=stats["notified"],
                                by_source=by_source, rows="\n".join(rows)))
    return path