"""Загрузка и валидация config.yaml."""
import os
import sys
import yaml

DEFAULT_CONFIG = "config.yaml"

def load_config(path: str = DEFAULT_CONFIG) -> dict:
    if not os.path.exists(path):
        sys.exit(f"❌ Файл конфигурации не найден: {path}")
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if not cfg.get("sources"):
        sys.exit("❌ В config.yaml не задан список источников (sources).")
    cfg.setdefault("notification_threshold", 10.0)
    cfg.setdefault("keywords", {"high": [], "medium": []})
    cfg.setdefault("priority_region", "surgut")
    cfg.setdefault("notifier", {"type": "console"})
    return cfg