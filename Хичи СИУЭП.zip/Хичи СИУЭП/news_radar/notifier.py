"""Отправка уведомлений редакции."""
import logging
import random
import requests

log = logging.getLogger("radar.notifier")

def _format(item: dict, score: float) -> str:
    """Форматирует текст уведомления."""
    region = "🔵 Сургут" if item["region"] == "surgut" else "🟡 Югра"
    return f"[{score:.1f}] {region} · {item['source']}\n{item['title']}\n{item['link']}"

def send_notification(item: dict, score: float, config: dict) -> bool:
    """Отправляет уведомление. Возвращает True, если доставка успешна."""
    cfg = config["notifier"]
    kind = cfg.get("type", "console")
    text = _format(item, score)

    # --- Консоль ---
    if kind == "console":
        print("\n" + "═" * 68)
        print("🔥 ВАЖНАЯ НОВОСТЬ")
        print("═" * 68)
        print(text)
        print("═" * 68)
        return True

    # --- Telegram ---
    if kind == "telegram":
        token = cfg.get("telegram_token")
        chat_id = cfg.get("telegram_chat_id")
        if not token or not chat_id:
            log.warning("Telegram не настроен — вывод в консоль.")
            print(text)
            return True
        try:
            r = requests.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                data={"chat_id": chat_id, "text": text, "disable_web_page_preview": False},
                timeout=10,
            )
            r.raise_for_status()
            return True
        except requests.RequestException as exc:
            log.error("Telegram ошибка: %s", exc)
            return False

    # --- MAX (если нужно) ---
    if kind == "max":
        token = cfg.get("max_token")
        chat_id = cfg.get("max_chat_id")
        if not token or not chat_id:
            log.warning("MAX не настроен — вывод в консоль.")
            print(text)
            return True
        url = "https://platform-api2.max.ru/messages"
        headers = {"Authorization": token, "Content-Type": "application/json"}
        payload = {"chat_id": int(chat_id), "text": text}
        try:
            r = requests.post(url, json=payload, headers=headers, timeout=15)
            r.raise_for_status()
            return True
        except requests.RequestException as exc:
            log.error("MAX ошибка: %s", exc)
            return False

    # --- VK (ВКонтакте) ---
    if kind == "vk":
        token = cfg.get("vk_token")
        peer_id = cfg.get("vk_peer_id")
        if not token or not peer_id:
            log.warning("VK не настроен — вывод в консоль.")
            print(text)
            return True

        # random_id должен быть уникальным для каждого сообщения
        random_id = random.randint(1, 2**31 - 1)

        url = "https://api.vk.com/method/messages.send"
        params = {
            "access_token": token,
            "v": "5.131",  # Актуальная версия API
            "peer_id": peer_id,
            "message": text,
            "random_id": random_id,
        }
        try:
            r = requests.post(url, params=params, timeout=15)
            r.raise_for_status()
            response = r.json()
            if "error" in response:
                log.error("VK ошибка API: %s", response["error"])
                return False
            log.info("Уведомление успешно отправлено в VK.")
            return True
        except requests.RequestException as exc:
            log.error("VK ошибка сети: %s", exc)
            return False

    log.warning("Неизвестный тип notifier: %s", kind)
    print(text)
    return True