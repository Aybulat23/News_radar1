#!/bin/bash
cd /home/guest/Desktop/news_radar
source .venv/bin/activate
python main.py >> radar_cron.log 2>&1