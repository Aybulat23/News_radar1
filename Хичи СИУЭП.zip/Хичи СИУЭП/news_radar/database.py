"""SQLite: история находок и защита от дублей."""
import sqlite3
from datetime import datetime

DB_PATH = "news_radar.db"

def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db() -> None:
    with _conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS seen_news (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guid TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                link TEXT,
                source TEXT,
                priority INTEGER,
                region TEXT,
                score REAL,
                notified INTEGER DEFAULT 0,
                found_at TEXT NOT NULL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_found_at ON seen_news(found_at)")

def is_new(guid: str) -> bool:
    with _conn() as conn:
        row = conn.execute("SELECT 1 FROM seen_news WHERE guid = ?", (guid,)).fetchone()
        return row is None

def save_news(item: dict, score: float, notified: bool) -> None:
    with _conn() as conn:
        conn.execute("""
            INSERT OR IGNORE INTO seen_news
                (guid, title, link, source, priority, region, score, notified, found_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            item["guid"], item["title"], item["link"], item["source"],
            item["priority"], item["region"], score, int(notified),
            datetime.now().isoformat(timespec="seconds"),
        ))

def get_history(limit: int = 20) -> list[dict]:
    with _conn() as conn:
        rows = conn.execute("""
            SELECT title, source, region, score, notified, found_at, link
            FROM seen_news ORDER BY found_at DESC, score DESC LIMIT ?
        """, (limit,)).fetchall()
        return [dict(r) for r in rows]

def get_stats() -> dict:
    with _conn() as conn:
        total = conn.execute("SELECT COUNT(*) FROM seen_news").fetchone()[0]
        notified = conn.execute("SELECT COUNT(*) FROM seen_news WHERE notified=1").fetchone()[0]
        by_source = conn.execute("""
            SELECT source, COUNT(*) AS cnt FROM seen_news GROUP BY source ORDER BY cnt DESC
        """).fetchall()
        return {"total": total, "notified": notified, "by_source": [dict(r) for r in by_source]}