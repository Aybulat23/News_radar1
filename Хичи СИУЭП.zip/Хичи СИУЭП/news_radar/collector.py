"""Сбор новостей из RSS-источников."""
import hashlib, time, logging
from datetime import datetime
import feedparser, requests

log = logging.getLogger("radar.collector")
HEADERS = {"User-Agent": "NewsRadar/1.0 (+siapress.ru editorial bot)"}
TIMEOUT = 15

def _make_guid(entry: dict, source_name: str) -> str:
    raw = entry.get("id") or entry.get("link") or entry.get("title") or ""
    if not raw:
        raw = f"{source_name}::{entry.get('title', '')}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]

def _extract_published_ts(entry: dict) -> float | None:
    for key in ("published_parsed", "updated_parsed"):
        tm = entry.get(key)
        if tm:
            try:
                return time.mktime(datetime(*tm[:6]).timetuple())
            except Exception:
                pass
    return None

def fetch_source(source: dict) -> list[dict]:
    url = source["url"]
    try:
        resp = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
        resp.raise_for_status()
    except requests.RequestException as exc:
        log.warning("Не удалось получить %s: %s", url, exc)
        return []
    feed = feedparser.parse(resp.content)
    if feed.bozo and not feed.entries:
        log.warning("RSS повреждён или пустой: %s", url)
        return []
    items = []
    for entry in feed.entries:
        items.append({
            "guid": _make_guid(entry, source["name"]),
            "title": (entry.get("title") or "Без заголовка").strip(),
            "link": entry.get("link", ""),
            "summary": entry.get("summary", ""),
            "source": source["name"],
            "priority": source["priority"],
            "region": source.get("region", "unknown"),
            "published_ts": _extract_published_ts(entry),
        })
    log.info("Источник %-32s → %d записей", source["name"], len(items))
    return items

def fetch_all(config: dict) -> list[dict]:
    all_items = []
    for src in config["sources"]:
        all_items.extend(fetch_source(src))
    return all_items